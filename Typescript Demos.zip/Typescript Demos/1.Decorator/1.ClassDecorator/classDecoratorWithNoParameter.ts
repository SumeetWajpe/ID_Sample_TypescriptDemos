/**
 * Class decorator without parameter
*/

function MyClassDecorator(
    target: Function // The class the decorator is declared on
    ) {
    console.log("ClassDecorator called on: ", target);
}

@MyClassDecorator
class ClassDecoratorExample {
}