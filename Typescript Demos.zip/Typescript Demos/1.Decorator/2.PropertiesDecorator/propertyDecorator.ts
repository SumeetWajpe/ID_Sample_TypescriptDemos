function PropertyDecorator(
    target: Object, // The prototype of the class
    propertyKey: string  // The name of the property    

) {

    if(someextraParam
    console.log("PropertyDecorator called on: ", target, propertyKey);
}

class PropertyDecoratorExample {
    @PropertyDecorator
    name: string;

    @PropertyDecorator
    author: string;

    @PropertyDecorator
    cost: number;
}