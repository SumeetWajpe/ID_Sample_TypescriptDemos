"use strict";
exports.PI = 3.14;
