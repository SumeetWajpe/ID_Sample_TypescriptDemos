export interface StringValidator {
        isAcceptable(s: string): boolean;
    }


export const PI = 3.14;