﻿

interface Book {
    id: number;
    title: string;
    available: boolean;
    category: Category;
    pages?: number;
    markDamaged?: (reason: string) => void;// Function type

}

enum Category { Biography, Poetry, Fiction, Inspirational, Children }

function GetAllBooks():Book[] {

    let books = [
        { id:1, title: 'Wings Of Fire', author: 'APJ Kalam', available: true, category: Category.Inspirational },
        { id:2, title: 'Playing It My Way', author: 'Sachin Tendulkar', available: false, category: Category.Biography },
        { id:3, title: 'I Know Why the Caged Bird Sings', author: 'Maya Angelou', available: true, category: Category.Poetry },
        { id:4,title: 'I am Malala', author: 'Malala', available: true, category: Category.Biography }
    ];

    return books;
}

function LogFirstAvailableBook(books): void {

    let numberOfBooks: number = books.length;
    let firstAvailable: string = '';

    for (let currentBook of books) {

        if (currentBook.available) {

            firstAvailable = currentBook.title;
            break;

        }

    }

    console.log('total books : ' + numberOfBooks);
    console.log('first available : ' + firstAvailable);

}

// write a function GetBookTitlesByCategory(category)
//that returns an array of strings of(title) for a category


function GetBookTitlesByCategory(categoryFilter: Category): Array<string> {

    console.log('Getting books in category: ' + Category[categoryFilter]);

    const allBooks = GetAllBooks();
    const filteredTitles: string[] = [];

    for (let currentBook of allBooks) {
        if (currentBook.category === categoryFilter) {
            filteredTitles.push(currentBook.title);
        }
    }
    return filteredTitles;
}

function LogBookTitles(titles: string[]): void {

    for (let title of titles) {
        console.log(title);
    }
}


let biographyBooks = GetBookTitlesByCategory(Category.Biography);
//LogBookTitles(biographyBooks);


//biographyBooks.forEach(function (title, index, arr) {
//    console.log(++index + " " + title);
//}); // older way

// arrow functions
biographyBooks.forEach((title, index, arr) => console.log(++index + " " + title));



var IdGenerator: (str_id: number, str_name: string) => string;// Function Type

IdGenerator = CreateCustId;// assign

function CreateCustId(id: number, name: string): string {

    return id + name;
}

//var genId = IdGenerator(10, 'ABC');
//console.log(genId);


function GetTitles(author: string): string[];
function GetTitles(available: boolean): string[];
function GetTitles(bookProperty: any): string[] {
    const allBooks = GetAllBooks();
    const foundTitles: string[] = [];

    //if (typeof bookProperty == 'string') {
    //    // get all books by a particular author
    //    for (let book of allBooks) {
    //        if (book.author === bookProperty) {
    //            foundTitles.push(book.title);
    //        }
    //    }
    //}

    //else if (typeof bookProperty == 'boolean') {
    //    // get all books based on specified availability
    //    for (let book of allBooks) {
    //        if (book.available === bookProperty) {
    //            foundTitles.push(book.title);
    //        }
    //    }
    //}
    return foundTitles;
}


//GetTitles('James Wales');



function PrintBook(book: Book): void {

    console.log(book.title + " " + book.id);

}

var aBook = {
    id: 1,
    title: 'Wings Of Fire',
    author: 'APJ Kalam',
    available: true,
    category: Category.Inspirational,
    markDamaged: (reason: string) => console.log('Damaged : ' + reason)
};
PrintBook(aBook);
aBook.markDamaged('Missing Back Cover !');

//var notAbook = { Name: 'NotABook' };
//PrintBook(notAbook); // error !


// Interface extending and interface

//interface Emp {

//    empid: number;
//}

interface Person {
    name: string;
    email: string;
}


interface Author extends Person {
    noOfBooksWritten: number;    
}
interface Librarian extends Person {
    department: string;
    assistForCustomer: (cname:string) => string;
}


//let anAuthor: Author = {};
//let aLibrarian:Librarian = {};


//interface Author extends Emp {
//    noOfBooksWritten: number;
//    employee: Emp;
//}

//let anAuthor: Author = {
//    empid: 1,
//    employee: { empid: 10 },
//    noOfBooksWritten: 10
//};


class UniversityLibrarian implements Librarian {
    name: string;
    email: string;
    department: string;
    assistForCustomer(cname: string):string {
        return cname + ' is assisted by ' + this.name;
    }
}

let librarian_un: Librarian = new UniversityLibrarian();
librarian_un.name = 'Anil';
librarian_un.email = 'anil@gmail.com';
librarian_un.department = "University";
var msg = librarian_un.assistForCustomer('John');
console.log(msg);




class Car {

    name: string;
   private speed: number;

    constructor(theName: string,theSpeed:number) {
        this.name = theName;
        this.speed = theSpeed;
    }

    accelerate() {
       // console.log('VVRRRROOMMM..@' + theSpeed + ' kmph !');
        console.log(`${this.name} is VRRRROMMMing.. @  ${this.speed} kmph !`);
    }

}

let carOne = new Car('i20',200);

console.log(carOne.name);
carOne.accelerate();

class JamesBondCar extends Car {

    canFly: boolean;
    canSubmerge: boolean;

    constructor(n: string, s: number, canFly: boolean, canSubmerge: boolean) {

        super(n, s); // calls base class ctor !
        this.canFly = canFly;
        this.canSubmerge = canSubmerge;

    }
}

let jbc = new JamesBondCar('Houston', 400, true, true);



var genericArray = new Array<string>();

//genericArray.push(10);


function Swap<T>(x: T, y: T) {

    let temp: T;
    temp = x;
    x = y;
    y = temp;
}

Swap<string>("Hello", "World");
Swap<number>(10,20);


interface PersonDetails {
    firstName: string;
    lastName: string;
}


var abc = 0;
var json = '{"firstName":"Sumeet","Name":"Wajpe"}';


var myJSON = {
    parse: function <T>(data: string):T {
        return JSON.parse(data);
    }
}

var jsObj = myJSON.parse<PersonDetails>(json);
console.log(jsObj.firstName);
console.log(jsObj.lastName);


class Point<T,V>{

    x: T;
    y: V;
}


var point = new Point<number,string>();


